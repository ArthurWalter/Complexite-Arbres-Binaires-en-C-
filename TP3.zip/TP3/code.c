

#include <stdio.h>
#include <stdlib.h>

/* --------------------------------------------------- 	*/
/*	structures, constructeurs et selecteurs 	*/
/* --------------------------------------------------- 	*/

struct noeud{
  int info;
  struct noeud *fils_gauche;
  struct noeud *fils_droit;
};

typedef struct noeud *Arbre;

struct noeud *racine(Arbre A){
  return A;
}

Arbre ArbreVide() {
	return NULL ;
}

Arbre Cons (int info, Arbre fils_gauche, Arbre fils_droit) {
	Arbre A ;
	A = (Arbre) malloc(sizeof(struct noeud)) ;
	A->info = info ;
	A->fils_gauche = fils_gauche ;
	A->fils_droit = fils_droit ;
	return A ;
}

struct noeud* CreerArbreBinaire(int info){
   struct noeud *noeud = (struct noeud *)malloc (sizeof(struct noeud));
  noeud = calloc(1, sizeof(struct noeud));
  noeud -> info = info;
  noeud -> fils_gauche = NULL;
  noeud -> fils_droit = NULL;
  return noeud;
}

Arbre FilsGauche(Arbre A) {
	return (A->fils_gauche) ;
}

Arbre FilsDroit(Arbre A) {
	return (A->fils_droit) ;
}

int Info (Arbre A) {
	return (A->info) ;
}

int EstVide (Arbre A) {
	return A == NULL ;
}

int EstFeuille(Arbre A) {
	return (A != NULL && EstVide(FilsGauche(A)) && EstVide(FilsDroit(A))) ;
}

struct noeud *creer_noeud(int info, struct noeud *fils_gauche, struct noeud *fils_droit){
   struct noeud *nouveau = (struct noeud *)malloc (sizeof(struct noeud));

   nouveau-> info = info;
   nouveau-> fils_gauche = fils_gauche;
   nouveau-> fils_droit = fils_droit;

   return nouveau;
}


/* --------------------------------------------------- 	*/
/*	Affichage d'un Arbre binaire			*/
/* --------------------------------------------------- 	*/

void affichage_infixe(Arbre A){

  if(!EstVide(A)){
    affichage_infixe(FilsGauche(A));
    printf("%d  ", Info(A));
    affichage_infixe(FilsDroit(A));
  }
}

/* ------------------------------------------------------------ */
/* int CalculEfficace et NombreArbresEfficace et NombreArbres */
/* ------------------------------------------------------------ */
int NombreArbres(int n){
	if(n <= 1){
		return 1;
	} else {
		int res = 0;
		int gauche = 0;
    int droite = 0;

		for(int i = 1 ;i <= n;i++){
      droite = NombreArbres(n - i);
			gauche = NombreArbres(i - 1);
			res += gauche * droite;
		}
		return res;
	}
}

int CalculEfficace(int n, int *tab){
  int res = 0;
    if(n < 0)
      return 0;
      else if(n <= 1)
        return 1;
    for(int i = 0; i < n; i++){
      if(tab[i] == -1)
        tab[i] = CalculEfficace(i, tab);
      if(tab[n - 1 - i] == -1)
        tab[n - 1 - i] = CalculEfficace(n - 1 - i, tab);
  res += tab[i] * tab[n - 1 - i];
  }
  return res;
}

int NombreArbresEfficace(int n){
  int *tab = malloc(n * sizeof(int));
    for(int i = 0; i < n; i++)
      tab[i] = -1;
    return CalculEfficace(n, tab);
}
/* ------------------------------------------------------------ */
/* 	Verif Arbre binaire */
/* ------------------------------------------------------------ */

int VerifieCondition(Arbre A, int *min, int *max){
	int i;
	*min = *max = Info(A);
	if(!EstVide(FilsGauche(A)))
		if(!VerifieCondition(FilsGauche(A), &i, max) || !(Info(A) > *max))
			return 0;
	if(!EstVide(FilsDroit(A)))
		if(!VerifieCondition(FilsDroit(A), min, &i) || !(Info(A) <= *min))
			return 0;
	return 1;
}

int Verifie(Arbre A){
	int min, max;
    if(!EstVide(A))
      return VerifieCondition(A, &min, &max);
}

/* ------------------------------------------------------------ */
/* 	appartient et appartient avec le nb de comparaisons  */
/* ------------------------------------------------------------ */

int appartient(Arbre A, int valeur){
	if(A == NULL)
		return 0;
	if(valeur == Info(A))
		return 1;
	if(valeur < Info(A))
		return appartient(FilsGauche(A), valeur);
	else
		return appartient(FilsDroit(A), valeur);
}

int appartientCompare(Arbre A, int valeur){
	if(A == NULL)
		return 0;
	if(valeur == Info(A))
		return 1;
	if(valeur < Info(A))
		return 1 + appartientCompare(FilsGauche(A), valeur);
	else
		return 1 + appartientCompare(FilsDroit(A), valeur);
}

/* ------------------------------------------------------------ */
/* 	nb maximale et minimale d'un Arbre */
/* ------------------------------------------------------------ */

int MaxArbre(Arbre A){
	while(!EstVide(FilsDroit(A)))
		A = FilsDroit(A);
	return Info(A);
}

int MinArbre(Arbre A){
	while(!EstVide(FilsGauche(A)))
		A = FilsGauche(A);
	return Info(A);
}

/* ------------------------------------------------------------ */
/* 	Creation des Arbre1, Arbre2, Arbre3 */
/* ------------------------------------------------------------ */

/*
  12
9    8
*/
Arbre Arbre1(){
  printf("Arbre 1 :\n\n");
  return Cons(12, Cons(9, NULL, NULL), Cons(8, NULL, NULL));
}
/*
    12
  9
    5
  7
*/

Arbre Arbre2(){
  printf("Arbre 2 :\n\n");
  Arbre A = Cons(5, Cons(7, NULL, NULL), NULL);
  Arbre B = Cons(9, NULL, A);
  return Cons(12, B, NULL);
}
/*
      12
   9      8
1   5        4
          7     6
*/
Arbre Arbre3(){
  printf("Arbre 3 :\n\n");
  Arbre A9 = Cons(9, Cons(1, NULL, NULL), Cons(5, NULL, NULL));
  Arbre B4 = Cons(4, Cons(7,NULL, NULL), Cons(6, NULL, NULL));
  Arbre C8 = Cons(8, NULL, B4);
  return Cons(12, A9, C8);
}

/* --------------------------------------------------- 	*/
/*	Insertion d'un element dans un ABR		*/
/* --------------------------------------------------- 	*/

Arbre Inserer (Arbre A, int x) {
	if (EstVide(A)) {
		return Cons(x, ArbreVide(), ArbreVide()) ;
	} else {
		if (Info(A) > x)
		  return Cons (Info(A), Inserer(FilsGauche(A), x), FilsDroit(A)) ;
		else
		  return Cons (Info(A), FilsGauche(A), Inserer(FilsDroit(A), x)) ;
	}
}

/* --------------------------------------------------- 	*/
/*	ABR : Arb1, Arb2 et Arb3 avec Inserer :		*/
/* --------------------------------------------------- 	*/


Arbre arb1(){
  printf("%s\n", "Arb1 :\n");
  Arbre A = ArbreVide();
  A = Inserer(A,6);
  A = Inserer(A,4);
  A = Inserer(A,2);
  A = Inserer(A,7);
  A = Inserer(A,5);
  A = Inserer(A,1);
  return A;
}

Arbre arb2(){
  printf("%s\n", "Arb2 :\n");
  Arbre A = ArbreVide();
  A = Inserer(A,5);
  A = Inserer(A,4);
  A = Inserer(A,2);
  A = Inserer(A,7);
  A = Inserer(A,6);
  A = Inserer(A,1);
  return A;
}

Arbre arb3(){
  printf("%s\n", "Arb3 :\n");
  Arbre A = ArbreVide();
  A = Inserer(A,7);
  A = Inserer(A,1);
  A = Inserer(A,4);
  A = Inserer(A,5);
  A = Inserer(A,6);
  A = Inserer(A,2);
  return A;
}
/* --------------------------------------------------- 	*/
/*	Recherche d'un element dans un ABR		*/
/* --------------------------------------------------- 	*/

int Recherche (Arbre A, int x) {
// renvoie le nb de comparaisons pour trouver l'info x
	if (EstVide(A))
		return 0 ;
	else {
		if (Info(A) == x)
			return 1 ;
		else {
			if (Info(A) > x)
				return 2 + Recherche (FilsGauche(A), x) ;
			else
				return 2 + Recherche (FilsDroit(A), x) ;

		}
	}
}

/* ------------------------------------------------------------ */
/* 	calcul de grandeurs caracteristiques d'un Arbre binaire */
/* ------------------------------------------------------------ */

int NbFeuilles (Arbre A) {

	if (!EstVide(A)) {
		if (EstFeuille(A))
			return 1 ;	// une feuille
		else
			// somme des feuilles des sous-Arbres gauche et droit
			return (NbFeuilles(FilsGauche(A)) + NbFeuilles(FilsDroit(A))) ;
	} else {
		return 0 ; //un Arbre vide n'a pas de feuille
	}
}

static int max (int h1, int h2) {
	if (h1>h2)
		return h1 ;
	else
		return h2 ;
}

int Hauteur (Arbre A) {
	if (!EstVide(A)) {
		if (EstFeuille(A))
		      return 1 ;	// arbre de hauteur 1
		else
		      // 1 + max des hauteurs des sous-Arbres gauche et droit
		      return 1 +
			max(Hauteur(FilsGauche(A)), Hauteur(FilsDroit(A)));
	} else {
		return 0 ; // un Arbre vide est de hauteur 0
	}

}

static void ParcoursNiveaux (Arbre A, int niveau, int T[]) {
// calcule dans t[i] le nombre de noeuds de niveau i de l'Arbre A
	if (!EstVide(A)) {
		ParcoursNiveaux (FilsGauche(A), niveau+1, T) ;
		ParcoursNiveaux (FilsDroit(A), niveau+1, T) ;
		T[niveau] = T[niveau] + 1 ;
	}
}


void NoeudsParNiveau(Arbre A) {
  int NoeudsParNiveau[Hauteur(A)];
	int i;

	for (i=0 ; i<Hauteur(A) ; i++)
		NoeudsParNiveau[i] = 0 ;

	ParcoursNiveaux (A, 0, NoeudsParNiveau) ;

	for (i=0 ; i<Hauteur(A) ; i++)
		printf(" \t nombre de noeuds de niveau %d : %d \n", i, NoeudsParNiveau[i]) ;
}


int Poids (Arbre A) {
	int NoeudsParNiveau[Hauteur(A)];
	int i;
  int poids=0;

	for (i=0 ; i<Hauteur(A) ; i++)
		NoeudsParNiveau[i] = 0 ;

	ParcoursNiveaux (A, 0, NoeudsParNiveau) ;
	for (i=0; i<Hauteur(A) ; i++)
		poids = poids + i * NoeudsParNiveau[i] ;
	return poids ;
}

int main(){

  /* ------------*/
  /* 	Partie 1 : */
  /* ------------*/

  printf("Affichage infixee des Arbres 1, 2 et 3 : \n\n");

  affichage_infixe(Arbre1());
  printf("\n\n");
  affichage_infixe(Arbre2());
  printf("\n\n");
  affichage_infixe(Arbre3());
  printf("\n\n");


  printf("calcul nombre de feuille des Arbres 1, 2 et 3 : \n\n");
  printf("%d\n",NbFeuilles(Arbre1()));
  printf("%d\n",NbFeuilles(Arbre2()));
  printf("%d\n",NbFeuilles(Arbre3()));
  printf("\n");

  printf("calcul de la taille des Arbres 1, 2 et 3 : \n\n");
  NoeudsParNiveau(Arbre1());
  NoeudsParNiveau(Arbre2());
  NoeudsParNiveau(Arbre3());
  printf("\n");

  printf("calcul de la hauteur des Arbres 1, 2 et 3 : \n\n");
  printf("%d \n",Hauteur(Arbre1())-1);
  printf("%d \n",Hauteur(Arbre2())-1);
  printf("%d \n\n",Hauteur(Arbre3())-1  );

  printf("Calcul des poids des Arbres : \n\n");
  printf("Poids : %d \n\n", Poids(Arbre1()));
  printf("Poids : %d \n\n", Poids(Arbre2()));
  printf("Poids : %d \n\n", Poids(Arbre3()));

// NombreArbresEfficace
  for(int i = 0; i < 20; i++)
  printf("Nombre d'Arbres possible pour %d noeuds : %d\n", i, NombreArbres(i));
	printf("\n");
	printf("Methode Efficace : (execution quasiment instantannee) :\n");
	printf("\n");
	for(int i = 0; i < 20; i++)
  printf("Nombre d'Arbres possible pour %d noeuds : %d\n", i, NombreArbresEfficace(i));
//fin

/* ------------*/
/* 	Partie 2 : */
/* ------------*/

  printf("\n");
  printf("Arbre binaire de recherche : (A)\n\n");
  affichage_infixe(arb1());
 //verifArbreBinaire(arb1());
  printf("\n\n");
  affichage_infixe(arb2());
  //verifArbreBinaire(arb2());
  printf("\n\n");
  affichage_infixe(arb3());
  //verifArbreBinaire(arb3());
  printf("\n");
  printf("\n\n");

//partie verification ArbreBinaire
  Arbre A1 = Arbre1();
	printf("Vérification que Arbre1 est bien un arbre binaire :\n");
	if(Verifie(A1) > 0)
		printf("Après vérification, Arbre1 est bien un arbre binaire.\n");
	else
		printf("Après vérifiaction, Arbre1 n'est pas un arbre binaire.\n");
	printf("\n");

	printf("Vérification que abr1 est bien un arbre binaire :\n");
	if(Verifie(arb1()) > 0)
		printf("Après vérification, abr1 est bien un arbre binaire.\n");
	else
		printf("Après vérifiaction, abr1 n'est pas un arbre binaire.\n");
	printf("\n\n");

//recherche de valeurs
Arbre Abr1 = arb1();
Arbre Arb2 = arb2();
Arbre Abr3 = arb3();
  printf("Recherche de 12 dans Arbre1 :\n\n");
  if(appartient(A1, 12) == 1)
    printf("Après recherche, la valeur 12 est bien présente dans Arbre1.\n");
  else
    printf("Après recherche, la valeur 12 n'est pas présente dans Arbre1.\n");
  printf("\n");

  printf("Recherche de 0 dans abr1 :\n\n");
  if(appartient(Abr1, 0) == 1)
    printf("Apèrs recherche, la valeur 0 est bien présente dans abr1.\n");
  else
    printf("Après recherche, la valeur 0 n'est pas présente dans abr1.\n");
  printf("\n");

  //appartientCompare
  printf("Comparaison du nombre d'opérations pour la recherche de 0 parmi les trois arbres abr1, arb2 et abr3 :\n");
  printf("\n");
  if((appartientCompare(Abr1, 0)) < appartientCompare(Arb2, 0)){
    if((appartientCompare(Abr1, 0)) < appartientCompare(Abr3, 0))
      printf("La recherche sur abr1 est celle avec le plus faible nombre d'opérations, %d opération(s) a suffit, la recherche sur arb2 a execute %d opérations et celle sur abr3 a execute %d opérations.\n",
      appartientCompare(Abr1, 0), appartientCompare(Arb2, 0), appartientCompare(Abr3, 0));
    else
    printf("La recherche sur abr3 est celle avec le plus faible nombre d'opérations, %d opération(s) a suffit, la recherche sur abr1 a execute %d opérations et celle sur arb2 a execute %d opérations.\n",
       appartientCompare(Abr3, 0), appartientCompare(Abr1, 0), appartientCompare(Arb2, 0));
  }

  else{
    if((appartientCompare(Arb2, 0)) < appartientCompare(Abr3, 0))

    printf("La recherche sur arb2 est celle avec le plus faible nombre d'opérations, %d opération(s) a suffit, la recherche sur abr1 a execute %d opérations et celle sur abr3 a execute %d opérations.\n",
       appartientCompare(Arb2, 0), appartientCompare(Abr1, 0), appartientCompare(Abr3, 0));
    else
    printf("La recherche sur abr3 est celle avec le plus faible nombre d'opérations, %d opération(s) a suffit, la recherche sur abr1 a execute %d opérations et celle sur abr2 a execute %d opérations.\n",
       appartientCompare(Abr3, 0), appartientCompare(Abr1, 0), appartientCompare(Arb2, 0));
  }

  printf("\n");
  printf("Valeur maximale de arb1 : %d, valeur minimale : %d\n", MaxArbre(Abr1), MinArbre(Abr1));
  printf("\n");
  printf("Valeur maximale de arb2 : %d, valeur minimale : %d\n", MaxArbre(Arb2), MinArbre(Arb2));
  printf("\n");
  printf("Valeur maximale de arb3 : %d, valeur minimale : %d\n", MaxArbre(Abr3), MinArbre(Abr3));
  printf("\n\n");
  return -1;
}
